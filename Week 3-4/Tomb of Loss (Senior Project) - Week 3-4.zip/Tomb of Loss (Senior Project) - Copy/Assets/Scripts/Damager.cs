using UnityEngine;

public class Damager : MonoBehaviour
{
    public int damageAmount = 20;
    private Health healthScript;
    public bool isBullet;
    public float damageLimiter = 1.0f;
    private bool hitable;

    private void OnTriggerEnter2D(Collider2D other) // Use OnTriggerEnter2D for 2D games
    {
        Debug.Log(gameObject.name + " has been hit!"); // debug
        healthScript = other.GetComponent<Health>(); // Try to get the Health component from the object hit

        if (healthScript != null)
        {
            healthScript.Damage(damageAmount);

        }

        // Optional: Destroy the damage dealing object on impact (like a bullet)
        if (isBullet == true)
        {
            Destroy(gameObject);
        }
    }

}
