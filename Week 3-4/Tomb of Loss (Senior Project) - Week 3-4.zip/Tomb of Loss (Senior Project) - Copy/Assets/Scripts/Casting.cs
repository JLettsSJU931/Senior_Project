// James Letts Brennan Duff
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Casting: MonoBehaviour
{

    private Camera mainCam;
    private Vector3 mousePos;
    public GameObject spell;
    public Transform spellTransform;
    public bool castable;
    private float timer;
    public float castTime;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        mainCam = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();  
    }

    // Update is called once per frame
    void Update()
    {
        mousePos = mainCam.ScreenToWorldPoint(Input.mousePosition);

        Vector2 rotation = mousePos - transform.position;

        float rotZ = Mathf.Atan2(rotation.y, rotation.x)*Mathf.Rad2Deg;

        transform.rotation = Quaternion.Euler(0,0,rotZ);

        if (!castable)
        {
            timer += Time.deltaTime;
            if (timer > castTime)
            {
                castable = true;
                timer = 0;
            }
        }
        if (Input.GetMouseButton(0) && castable)
        {
            castable = false;
            Instantiate(spell, spellTransform.position, Quaternion.identity);
        }
    }
}
